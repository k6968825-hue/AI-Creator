# AI Creator Android Starter v1.1

Mobile-first Android WebView project for AI Creator.

## Included
- Android Studio project source (Kotlin + WebView)
- Flow-inspired video studio interface (original branding/design)
- Default video duration set to 60 seconds
- Style and language selectors
- Video planning, image-to-video concept, storyboard, chat, writing and translator screens
- Local prompt history stored on device
- Free demo mode; no API key or payment required

## Important
This is **not yet a compiled APK** and does not render real AI videos/images. It creates demo production plans. Real AI generation requires a model/provider and usually a secure backend. Provider free quotas can change; unlimited free generation cannot be guaranteed. Do not put secret API keys in the app.

## Build
Open this folder in Android Studio, sync Gradle, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
Application ID: com.aicreator.app
Minimum Android: 6.0 (API 23)
Compile SDK: 35

A Gradle wrapper is not included.

## Build an APK using GitHub from your phone
1. Upload the contents of this project folder to a GitHub repository (the `.github/workflows/build-apk.yml` file must be included).
2. Open the repository on GitHub and tap **Actions**.
3. Select **Build AI Creator APK**, then tap **Run workflow** (or wait for the first push build).
4. When the run finishes with a green check, open that run and download the **AI-Creator-debug-APK** artifact.
5. Extract the downloaded ZIP on your phone. The APK inside is `app-debug.apk`.

This workflow builds the Android app shell/demo. It does not add a real AI video-generation service.
